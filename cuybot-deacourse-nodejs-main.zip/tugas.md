# TUGAS!

1. munculkan menu Listing COMMANDS yang bot kita punya lewat TOMBOL ketika user ketik !commands
2. tambahkan fitur baru dari API public apapun
3. buat identifier / custom prefix commands menjadi flexibel contoh:
        awalnya misalnya si command harus pake !
        ceritanya suatu saat lu punya 100 fitur
        dan ketika suatu hari lu pengen ganti prefix ! menjadi #
        tanpa harus kerepotan ganti 1 per 1 prefix commands nya, lu harus bisa buat itu jadi lebih mudah dan flexibel!!!
4. pisahkan utility function yang ada di dalam class (JANGAN DIRECT FUNCTION komparasi yang ada di variabel "isInCommand".
5. EXPLORE function bawaan parent class (TELEGRAMBOT), contoh sendPhoto, sendLocation, button reply, forwardMessage dan lain2...

### Jangan lupa share story ke IG dea.afrizal :)